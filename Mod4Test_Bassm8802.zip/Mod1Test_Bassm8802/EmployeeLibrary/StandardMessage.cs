﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
   public static class StandardMessage
    {
        public static string DisplayMenu()
        {
            return "1. Enter\n2. Exit";
        }
    }
}
