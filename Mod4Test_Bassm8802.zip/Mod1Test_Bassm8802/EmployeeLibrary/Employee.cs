﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
   public class Employee
   {
        // Fields
        private string _name;
        private string _phoneNumber;
        private string _age;
        // Constructers
        // Default
        public Employee()
        {
            Name = "";          
            PhoneNumber = "";
            Age = "";
        }
        // Custom
        public Employee(string name, string age, string phoneNumber)
        {
            Name = name;
            PhoneNumber = phoneNumber;
            Age = age;
        }
        // Full Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }
        public string Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }
    }
}
