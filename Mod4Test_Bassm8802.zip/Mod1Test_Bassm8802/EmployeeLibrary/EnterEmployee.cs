﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EmployeeLibrary
{
    public class EnterEmployee
    {
        //ask for user to input employee information
        public void Employee(List<Employee> inputList)
        {
            Employee thisEmployee = new Employee();

            Console.WriteLine("What is the employee's name?");
            Console.Write("=>");
            thisEmployee.Name = Console.ReadLine();

            Console.WriteLine("What is the employee's number?");
            Console.Write("=>");
            thisEmployee.PhoneNumber = Console.ReadLine();

            Console.WriteLine("What is the Employee's age?");
            Console.Write("=>");
            thisEmployee.Age = Console.ReadLine();

            inputList.Add(thisEmployee);
            Console.WriteLine(inputList);
            Console.ReadLine();
        }
    }
}
