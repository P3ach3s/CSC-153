﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace ConsoleUI
{
    /*
    * April 1, 2020
    * CSC 153
    * Michaela Bass
    * This program will show a menu, ask a user for input and then display their results
    */

    class Program
    {
        public static void Main(string[] args)
        {
            //create input var for user input and sentury for loop
            string input;
            Console.WriteLine(StandardMessage.DisplayMenu());
            input = Console.ReadLine();//call menu

        }
        public static void DisplayEmployees(string input)
        {
            if (input == "1") //validate user entry
            {
                Console.WriteLine(EnterEmployee.Employee());
            }
        }
        public static void DisplayGoodbyeMessage(string input)
        {
            if (input == "2")
            {
                Console.WriteLine("Have a great day!");
                Console.ReadLine();
            }
        }
    }
}

