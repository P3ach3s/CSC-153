﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemClassLibrary;

namespace ConsoleUI
{
   public class BuildRetailItem
   {
        public static void DisplayItems(List<string> items)
        {
            //create list to display
            List<string> Items = new List<string> {"Jacket, 12, $59.05 \n Jeans, 40, $34.95 \n Shirt, 20, $24.95" };
        }
    }
}
