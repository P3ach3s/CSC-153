﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RetailItemClassLibrary;

namespace ConsoleUI
{
    /**
    * Mar 30, 2020
    * CSC 153
    * MichaelaBass
    * 
    */
   public class Program
    {
        static void Main(string[] args)
        {
            //set exit variable
            bool exit = false;
            //do-while loop
            do
            {//switch statement
                Console.WriteLine(StandardMessages.DisplayMainMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine(BuildRetailItem.DisplayItems(List<string>items));
                        break;
                    case "2":
                        exit = false;
                        break;
                        //build default
                    default:
                        Console.WriteLine(StandardMessages.ShowChoiceError());
                        break;
                }


            } while (exit == false);

        }
    }
}
