﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
  public class StandardMessages
   {
        //menu
        public static string DisplayMainMenu()
        {
            return "1. Display inventory \n 2. Exit ";
        }
        //choice error 
        public static string ShowChoiceError()
        {
            return "Not a valid Choice!";
        }
    }
}
