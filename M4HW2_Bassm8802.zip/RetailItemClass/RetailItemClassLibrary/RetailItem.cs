﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailItemClassLibrary
{
    public class RetailItem
    {
        //Fields
        private string _description;
        private string _unitsOnHand;
        private string _price;

        //Constructor
        public RetailItem()
        {
            Description = "";
            UnitsOnHand = "";
            Price = "";
        }
        public RetailItem(string description, string unitsOnHand, string price)
        {
            Description = description;    
            UnitsOnHand=unitsOnHand;
            Price = price;
        }
        //Properties
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }
        }
        public string UnitsOnHand
        {
            get
            {
                return _unitsOnHand;
            }
            set
            {
                _unitsOnHand = value;
            }
        }
        public string Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }
        //Methods
    }
}
