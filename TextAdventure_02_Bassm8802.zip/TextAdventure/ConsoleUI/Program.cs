﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {            
            bool exit = false;
            string input;
            string[] rooms = new string[] { "Starting area", "Canadia", "Iceberg Lounge", "Arkham", "Lazarus Pit", "Gothem" };
            int index = 0;
            Console.WriteLine(Menus.StandardMessages.DisplayMenu());
            input = Console.ReadLine();
            do
            {
                switch (input)
                {
                    case "1":
                        if (index < rooms.Length && index >= 0)
                        {
                            Console.WriteLine($"Starting room-{rooms[index]}");
                        }
                        DisplayFirstRoom(rooms, ref index);
                        Console.WriteLine($"You have moved to the room -{rooms[index]}");
                        Console.WriteLine(Menus.StandardMessages.DisplayMenu());
                        input = Console.ReadLine();
                        break;
                    case "2":
                        if (index < rooms.Length && index >= 0)
                        {
                            Console.WriteLine($"Starting room-{rooms[index]}");
                        }
                        DisplayLastRoom(rooms, ref index);
                        Console.WriteLine($"You are now in the room -{rooms[index]}");
                        Console.WriteLine(Menus.StandardMessages.DisplayMenu());
                        input = Console.ReadLine();
                        break;
                    case "3":
                        int healthRemaining;
                        healthRemaining=DisplayAttack();
                        Console.WriteLine($"Your remaining health is: {healthRemaining}");
                        Console.WriteLine(Menus.StandardMessages.DisplayMenu());
                        input = Console.ReadLine();
                        break;
                    case "4":


                        break;
                }
            } while (exit == false);
        }
        public static void DisplayLastRoom(string[] rooms, ref int index)
        {
            if (index > 0)
            {
                index--;
            }
            else
            {
                Console.WriteLine("No More rooms!");
            }
        }
        public static void DisplayFirstRoom(string[] rooms, ref int index)
        {
            if (index < rooms.Length)
            {
                if (index != rooms.Length - 1)
                {
                    index++;
                }
                else
                {
                    Console.WriteLine("No More rooms!");
                }
            }

        }
        public static int DisplayAttack()
        {
            Random random = new Random();
            int hit = random.Next(21);
            int healthPoints = 20;
            int healthRemaining = healthPoints - hit;
            return healthRemaining;
        }
    }
    }

