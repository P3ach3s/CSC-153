﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menus
{
    public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Move North\n 2. Move South\n 3. Attack\n 4. Exit";
        }
        public static void DisplayWeapons(string[] weapon, ref int index)
        {
            string[] weapons = new string[] { "1. Sword of light and flame\n", " 2. Boomerang \n", " 3. Yamato\n", " 4. Rebellion" };

        }
        public static void DisplayTreasure(string[] potion, ref int index)
        {
            string[] potions = new string[] { "1. Demon Chalice\n", " 2. Philosopher's stone\n ", "3. Element 115" };
        }
        public static void DisplayPotions(string[] potion, ref int index)
        {
            string[] potions = new string[] { "1. Bantha Milk \n", " 2. Blood of the Demon\n "};
        }
        public static void DisplayItems(string[] item, ref int index)
        {
            List<string> items=new List<string> { "1. Chimichanga\n", " 2. Cyanide\n", " 3. Arsenic\n", " 4. Antique Engagement Ring" };
        }
        public static void DisplayMobs(string[] mob, ref int index)
        {
           List<string> mobs=new List<string> { "1. BAT GUY ", " 2. MATEO", "3. GUARDIANS", " 4. ASHLYNN", " 5. TERESA" };

        }

    }
}

