﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 2/12/2020
* CSC 153
* Michaela Bass
* This program will return 7 numbers stored in an array
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //create variable

            double[] numbers = new double [] { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };



            //print variable
            for (int x = 0; x< numbers.Length; x++)
            
            {
                Console.WriteLine(numbers[x]);
                
            }
            Console.ReadLine();
        }
    }
}
