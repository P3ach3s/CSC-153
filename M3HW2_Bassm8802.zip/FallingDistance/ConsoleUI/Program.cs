﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    /*
    * Feb 24, 2020
    * CSC 153
    * Michaela Bass
    * This program will calculate how far an object has fallen based on how long it fell
    */
    class Program
    {
        public static void Main(string[] args)
        {
            Console.Write(ClassLibrary.WelcomeMessage(welcome));//calling from the class library
            double distance=0;//declare datatypes
            double fell;
            fell = FallingDistance(distance);//asssign the called method to a variable
            Console.WriteLine($"The object fell { fell} meters.");//print the called variable
            Console.ReadLine();

        }

        public static double FallingDistance(double distance)//creating the calculation method
        { 
            string input;//declaring datatypes
            double time;
            Console.WriteLine("How many seconds did the object fall? ");//ask for user input
            input = Console.ReadLine();//catch user input
            double.TryParse(input, out time);//switch user input from string to double
           
            distance = (0.5) * 9.8 * (time * time);//do the calculation
            return distance;//return the results of calculations
        }
    }
}
