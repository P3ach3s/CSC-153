﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class welcome_message
    {
        public static void WelcomeMessage(string welcome)
        {
            Console.WriteLine( "Welcome to the falling distance calculator!");

        }
    }

}
