﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClassLibrary;

namespace ConsoleUI
{
    public class BuildCar
    {
        public static void BuildACar(Car inputCar)
        {
            Console.Write("What is the year of the car? => ");
            inputCar.Year = Console.ReadLine();

            Console.Write("What is the make of the car? => ");
            inputCar.Make = Console.ReadLine();

        }
    }
}
