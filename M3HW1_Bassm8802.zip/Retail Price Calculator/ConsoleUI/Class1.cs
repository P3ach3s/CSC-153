﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    /**
     * Feb 24, 2020
     * CSC 153
     * Michaela Bass
     * This program will calculate retail price based on user input of wholesale price and the markup percentage
     */
    class Program
    {
        public static void Main(string[] args)
        {
            
            string input;//create datatypes for input, wholeSale, retailPrice and markUpPercent
            double wholeSale, retailPrice, markUpPercent;
            Console.Write("What is the wholesale price?");//ask for wholesale price
            input = Console.ReadLine();//collect data from user input
            Console.Write("What is the markup percentage?");//ask for wholesale price
            input = Console.ReadLine();
            double.TryParse(input, out wholeSale);//change a string to a double
            double.TryParse(input, out markUpPercent);
            Console.WriteLine();//create a break for readability
            retailPrice = CalculateRetail(markUpPercent, wholeSale);//call the CalculateRetail method

            Console.WriteLine($"Your retail price is ${retailPrice}");//calling the retailPrice variable
            Console.ReadLine();
        }
        public static double CalculateRetail(double wholeSale, double markUpPercent)//creating a method for retail price

        {
            double retailPrice;
            retailPrice = wholeSale + (markUpPercent * wholeSale);//calculate the retail price
            return retailPrice;//return the value of retail price
        }

    }
}
