﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    class Welcome_Message
    {

       public static void Welcome()
        {
            Console.WriteLine("Welcome to the retail price calculator!");
        }
    }
}
