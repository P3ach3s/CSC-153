﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    /*
  * Feb 26, 2020
  * CSC 153
  * Michaela Bass
  * This program will show a menu, ask a user for input and then display their results
  */

    class Program
    {
        public static void Main(string[] args)
        {
            //create input var for user input and sentury for loop
            string input;
            Console.ReadLine(EmployeeLibrary.StandardMessage.DisplayMenu());//call EmployeeLibrary and menu

        }
        
        public static string EnterName(string input)
        {
            if (EmployeeLibrary.StandardMessage.DisplayMenu() = 1) //validate user entry
            {
                int SIZE = 5;
                int nameIndex = 0;//create name index
                string[] employeeName = new string[SIZE];
                Console.Write("Enter employee's name -->");//ask for user input
                input = Console.ReadLine();//catch user input
                employeeName[nameIndex] = input;
                nameIndex++;
                return employeeName[nameIndex];//return user input
            }
        }
        public static string EnterNumber(string input)
        {
            if (Console.ReadLine(EmployeeLibrary.StandardMessage.DisplayMenu()) = 2)
            {
                int SIZE = 5;//create a size variable
                int phoneIndex = 0;//create phone index
                string[] employeePhone = new string[SIZE];

                Console.Write("Enter employee's phone number -->");//ask for user input
                input = Console.ReadLine();//catch user input
                employeePhone[phoneIndex] = input;
                phoneIndex++;
                return employeePhone[phoneIndex];//return user input
            }
        }
        public static int EnterAge(string input)
        {
           if (Console.ReadLine(EmployeeLibrary.StandardMessage.DisplayMenu()) = 3)
            {
                const int SIZE = 5;
                int number = 0;//declare variables and datatypes
                int employeeAge;

                Console.Write("Enter employee's age -->");
                input = Console.ReadLine();

                if (int.TryParse(input, out number))
                {
                    employeeAge = number;
                    
                    return employeeAge;//return value
                }
                else
                {
                    Console.WriteLine("Not a valid number!");
                }

            }
        }
        public static void DisplayEmployee(string input)
        {
            if (Console.ReadLine(EmployeeLibrary.StandardMessage.DisplayMenu()) = 4)//validate user entry
            {
                for (int index = 0; index < employeeAge.Count; index++)//create a for loop
                {
                    int SIZE = 5;
                    string[] employeeName = new string[SIZE];
                    string[] employeePhone = new string[SIZE];
                    string[] employeeAge = new string[SIZE];
                    Console.WriteLine($"Employee Name- {employeeName[index]}");//print employee name
                    Console.WriteLine($"Employee Phone- {employeePhone[index]}");//print employee phone
                    Console.WriteLine($"Employee Age- {employeeAge[index]}");//print employee age


                }
                Console.WriteLine();
            }
        }
        public static void DisplayAverageAge(int input)
        {
            if (Console.ReadLine(EmployeeLibrary.StandardMessage.DisplayMenu()) = 5)
            {
                Console.WriteLine(employeeAge.Average());//calculate and print employee average
                Console.WriteLine();
            }
        }
    }
}
