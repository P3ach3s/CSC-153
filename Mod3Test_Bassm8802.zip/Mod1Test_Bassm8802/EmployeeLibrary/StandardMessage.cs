﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
   public static class StandardMessage
    {
        public static string DisplayMenu(string input)
        {
            Console.WriteLine("1. Enter employee's name");
            Console.WriteLine("2. Enter employee's phone number");
            Console.WriteLine("3. Enter employee's age");
            Console.WriteLine("4. Display employee information ");
            Console.WriteLine("5. Display average age of employees");
            Console.WriteLine("6. Exit");
            Console.Write("-->");
            input = Console.ReadLine();
            return input;
        }
    }
}
