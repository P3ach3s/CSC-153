﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PreferredCustomerClassLibrary;

namespace ConsoleUI
{
    //Michaela Bass
    //This program is to calculate customer discount based on expendatures
    //CSC 153-0001
    //May 3, 2020
    public class Program
    {
        static void Main(string[] args)
        {
            //I thought I had a handle on this when we were going over it in class, but doing it on
            //my own I realized I am lost. I didn't want to turn nothing in, so here is what I could
            // get on my own
            Console.WriteLine(PreferredCustomer.ToString());
        }
    }   
}
