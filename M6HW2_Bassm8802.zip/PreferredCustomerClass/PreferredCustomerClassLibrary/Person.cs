﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class Person
    {
        
        public Person(string name, string address, string phone)
        {
            Name = name;
            Address = address;
            Phone = phone;
        }

        public string Name { get; set; }
        public string Address { get; set; }
        public string Phone { get; set; }
        public string Information { get; set; }
        //methods
        public void GetCustInformation()
        {
            Console.WriteLine("What is the customer's name?");
            Name = Console.ReadLine();
            Console.WriteLine("What is the customer's address?");
            Address = Console.ReadLine();
            Console.WriteLine("What is the customer's phone number?");
            Phone = Console.ReadLine();
        }
    }
}

