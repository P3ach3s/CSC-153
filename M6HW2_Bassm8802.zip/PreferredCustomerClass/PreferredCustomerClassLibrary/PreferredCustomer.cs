﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
   public class PreferredCustomer: Customer
    {
        public PreferredCustomer(string name, string address, string phone, string id,
           string email, int spentAmount)
           : base(name, address, phone, id, email, spentAmount)
        {
            DiscountLevel = SetDiscountLevel();      
        }

        public readonly decimal DiscountLevel;

        //calcualte discount percentage
        public decimal SetDiscountLevel()
        {
            int range = SpentAmount / 500;
            switch (range)
            {
                case 0:
                    return 0;
                    break;
                case 1:
                    return 0.05m;
                    break;
                case 2:
                    return 0.06m;
                    break;
                case 3:
                    return 0.07m;
                default:
                    return 0.1m;
                    break;
            }
        }

        public double GetDiscount()
        {
            return SpentAmount * (double)DiscountLevel;
        }

        public override double CalcAmount()
        {
            return base.CalcAmount() - GetDiscount();
        }

        public override string ToString()
        {
            return
                String.Format(
                    "CustomerID: {0}\nCustomer Name: {1}\nCustomerAddress: {2}\n" +
                    "Customer Phone: {3} \nCustomer Email: {4}" +
                    "Customer Spending: {5:C2}",
                    CustomerID, Name, Address, Phone, Email, SpentAmount
                    );
        }
    }
}

