﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreferredCustomerClassLibrary
{
    public class Customer : Person
    {
        public Customer(string name, string address, string phone, string id, string email, int spentAmount)
            : base(name, address, phone)
        {
            CustomerID = id;
            Email = email;
            SpentAmount = spentAmount;

        }

        public string CustomerID { get; set; }
        public string Email { get; set; }
        public int SpentAmount { get; set; }

        public virtual double CalcAmount()
        {
            return SpentAmount;
        }
       
    }
    
}
